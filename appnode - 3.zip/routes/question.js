/**  description
 *   author tangyue
 *   date 2016/4/14
 */
var express = require('express');
var router = express.Router();
var path = require('path');
var questionservice = require('../services/questionservice');
router.post('/questionList',function(req,res,next){
    questionservice.getQuetionList(req.body.curPage,req.body.eachNum,[],function(data){
        res.send(data);
    });
});
module.exports = router;
