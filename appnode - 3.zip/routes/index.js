/**  description
 *   author tangyue
 *   date 2016/4/14
 */
var express = require('express');
var path = require('path');
var router = express.Router();
router.get('/',function(req,res,next){
    res.redirect('../page/index.html');
});
module.exports = router;
