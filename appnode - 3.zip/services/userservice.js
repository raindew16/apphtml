/**  description
 *   author tangyue
 *   date 2016/4/14
 */
var userdao = require('../dao/userdao');
exports.login = function(params,callback){
    userdao.getUser(params,function(data){
        if(data[0].ucount===1){
            callback('index.html');
        }else{
            callback('login.html');
        }
    });
}
exports.register = function(params,callback){
    userdao.addUser(params,function(data){
        if(data.affectedRows===1){
            callback({success:1,content:'注册成功',url:'login.html'});
        }else{
            callback({success:0,content:'注册失败',url:'register.html'});
        }
    });
}
