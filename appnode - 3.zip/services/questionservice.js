/**  description
 *   author tangyue
 *   date 2016/4/15
 */
var service= require('../dao/questiondao');
exports.getQuetionList=function(curPage,eachNum,params,callback){
    service.getQuetionList(curPage,eachNum,params,function(data){
        callback(data);
    });
}