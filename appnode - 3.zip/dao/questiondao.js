/**  description
 *   author tangyue
 *   date 2016/4/15
 */
var dao= require('./database');
exports.getQuetionList=function(curPage,eachNum,params,callback){
    dao.getPageData('select * from question',curPage,eachNum,params,function(data){
        callback(data);
    });
}