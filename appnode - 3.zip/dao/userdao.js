/**  description
 *   author tangyue
 *   date 2016/4/14
 */
var dao= require('./database');
exports.getUser = function(params,callback){
    dao.operateData('select count(*) ucount from users u where u.username = ? and u.password = ?',
        [params.name,params.password],function(data){
               callback(data);
        });
}
exports.addUser = function(params,callback){
    dao.operateData("insert into users values (?,?,?,?,?,?,?,?,?)",params,function(data){
            callback(data);
        });
}