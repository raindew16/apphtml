/**  description
 *   author tangyue
 *   date 2016/4/14
 */
var mysql = require("../node_modules/mysql");
//��ȡ���ݿ�����
var connectDatabase = function(){
    return mysql.createConnection({
        host:'localhost',
        port:'3306',
        user:'root',
        password:'root',
        database:'f23'
    });
}

var operateData = function(sql,params,callback){
    var con=connectDatabase();
    con.query(sql,params,function(err,data){
        if(err) {
            console.log(err);
        }else {
            callback(data);
        }
    });
    con.end();
}

var getPageData = function(sql,curPage,eachNum,params,callback){
    var con=connectDatabase();
    con.query('select count(*) c from ('+sql+') q',params, function (err,data) {
            var count = data[0].c;
            var totalPage= Math.ceil(count/eachNum);
            sql+=' limit '+(curPage-1)*eachNum+','+eachNum;
            con.query(sql,params,function(err,data){
                if(err) {
                    console.log(err);
                }else {
                    var callData={
                        curPage:curPage,
                        eachNum:eachNum,
                        totalRecord:count,
                        totalPage:totalPage,
                        data:data
                    }
                    callback(callData);
                    con.end();
                }
            });

    });

}
exports.operateData = operateData;
exports.getPageData = getPageData;